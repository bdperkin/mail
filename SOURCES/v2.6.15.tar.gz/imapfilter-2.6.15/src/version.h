#ifndef VERSION_H
#define VERSION_H


/* Program's version number. */
#define VERSION		"2.6.15"

/* Program's copyright. */
#define COPYRIGHT	"Copyright (c) 2001-2019 Eleftherios Chatzimparmpas"


#endif				/* VERSION_H */
